# GMTools Configurable

Небольшой Android-проект с настраиваемым преобразованием сообщений.

## Формат

По умолчанию:

`{сло} 123 Привет`

преобразуется в:

`/pm 123 Привет`

Настройки находятся в корне проекта:

```json
{
  "trigger": "{сло}",
  "command": "/pm",
  "separator": " ",
  "keep_text": true
}
```

### Параметры

- `trigger` — префикс, который нужно распознавать.
- `command` — команда, подставляемая перед ID.
- `separator` — разделитель между частями.
- `keep_text` — сохранять ли текст после ID.

Например:

```json
{
  "trigger": "{личка}",
  "command": "/pm",
  "separator": " ",
  "keep_text": true
}
```

даёт:

`{личка} 456 Привет` → `/pm 456 Привет`

## Сборка

```bash
./gradlew assembleDebug
```

APK появится в:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Workflow `.github/workflows/build.yml` автоматически собирает APK при push в `main` и позволяет запустить сборку вручную.

Артефакт `GMTools-debug` можно скачать со страницы конкретного workflow run.