package com.example.gmtoolsconfigurable

import org.json.JSONObject

data class TransformConfig(
    val trigger: String,
    val command: String,
    val separator: String = " ",
    val keepText: Boolean = true
) {
    companion object {
        fun fromJson(json: String): TransformConfig {
            val o = JSONObject(json)
            return TransformConfig(
                trigger = o.optString("trigger", "{сло}"),
                command = o.optString("command", "/pm"),
                separator = o.optString("separator", " "),
                keepText = o.optBoolean("keep_text", true)
            )
        }
    }
}