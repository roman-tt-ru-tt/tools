package com.example.gmtoolsconfigurable

import android.content.Context

object ConfigLoader {

    fun load(context: Context): TransformConfig {
        val json = context.assets.open("config.json")
            .bufferedReader()
            .use { it.readText() }

        return TransformConfig.fromJson(json)
    }
}