package com.example.gmtoolsconfigurable

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val input = findViewById<EditText>(R.id.input)
        val output = findViewById<TextView>(R.id.output)
        val button = findViewById<Button>(R.id.transform)

        val config = ConfigLoader.load(this)

        button.setOnClickListener {
            val result = MessageTransformer.transform(input.text.toString(), config)

            output.text = result ?: "Формат не распознан"
        }
    }
}