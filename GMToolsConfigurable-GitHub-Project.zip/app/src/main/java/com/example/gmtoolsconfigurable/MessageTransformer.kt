package com.example.gmtoolsconfigurable

object MessageTransformer {

    /**
     * Converts:
     *   {сло} 123 Hello
     * to:
     *   /pm 123 Hello
     *
     * The first whitespace-separated token after the trigger is treated as ID.
     */
    fun transform(input: String, config: TransformConfig): String? {
        val trimmed = input.trim()

        if (!trimmed.startsWith(config.trigger)) {
            return null
        }

        val rest = trimmed.removePrefix(config.trigger).trim()
        if (rest.isEmpty()) return null

        val parts = rest.split(Regex("\\s+"), limit = 2)
        val id = parts[0]

        if (id.isBlank()) return null

        val text = if (parts.size > 1) parts[1].trim() else ""

        return if (config.keepText && text.isNotEmpty()) {
            config.command + config.separator + id + config.separator + text
        } else {
            config.command + config.separator + id
        }
    }
}